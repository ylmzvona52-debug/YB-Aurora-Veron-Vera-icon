package com.yb.aurora

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.role.RoleManager
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private var tts: TextToSpeech? = null
    private var torchOn = false
    private val micRequest = 741
    private val speechRequest = 742
    private val cyan = 0xFF50D9FF.toInt()
    private val gold = 0xFFFFC66D.toInt()
    private val bg = 0xFF070B12.toInt()
    private val panel = 0xFF111A28.toInt()
    private val muted = 0xFF9DAEC4.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        tts = TextToSpeech(this, this)
        showHome()
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) tts?.language = Locale("tr", "TR")
    }

    private fun base(title: String, subtitle: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(22))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(bg)
            addView(root)
        }
        setContentView(scroll)
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(label("YB", 23f, gold))
            addView(label("  AURORA", 13f, cyan).apply { letterSpacing = 0.16f })
        }
        root.addView(brand)
        root.addView(label(title, 25f, 0xFFFFFFFF.toInt()).apply {
            setPadding(0, dp(13), 0, dp(3)); letterSpacing = 0.04f
        })
        root.addView(label(subtitle, 10f, muted).apply { letterSpacing = 0.08f })
        root.addView(space(13))
        status = label("●  SİSTEM HAZIR  /  Komut bekleniyor", 11f, 0xFFE1EAF7.toInt()).apply {
            setPadding(dp(13), dp(12), dp(13), dp(12)); background = panelShape(0xFF172536.toInt(), cyan)
        }
        root.addView(status, match())
    }

    private fun showHome() {
        base("SİSTEM MERKEZİ", "ÖZGÜN ANDROID ARAYÜZÜ  /  VERON • VERA")
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(18), dp(16), dp(18))
            background = panelShape(0xFF0B1725.toInt(), cyan)
        }
        hero.addView(label("◉", 54f, cyan).apply { gravity = Gravity.CENTER; setShadowLayer(dp(18).toFloat(), 0f, 0f, cyan) })
        hero.addView(label("YB AURORA", 19f, 0xFFFFFFFF.toInt()).apply { gravity = Gravity.CENTER; letterSpacing = 0.18f })
        hero.addView(label("Akıllı sistemin hazır", 11f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) })
        root.addView(hero, LinearLayout.LayoutParams(-1, dp(178)).apply { setMargins(0, dp(8), 0, dp(10)) })
        section("İLETİŞİM")
        root.addView(row(btn("☎  Telefon", cyan) { openDialer() }, btn("✉  SMS", cyan) { openSms() }))
        root.addView(row(btn("◉  WhatsApp", 0xFF61D6A5.toInt()) { openWhatsApp() }, btn("◉  Gelen arama", gold) { showIncomingPreview() }))
        section("SİSTEM ARAÇLARI")
        root.addView(row(btn("▣  Kamera", cyan) { openIntent(Intent("android.media.action.IMAGE_CAPTURE")) }, btn("▧  Galeri", cyan) { openIntent(Intent(Intent.ACTION_VIEW).setType("image/*")) }))
        root.addView(row(btn("⌘  Kontrol merkezi", gold) { showControlCenter() }, btn("⚙  Özel ayarlar", gold) { showSettings() }))
        section("YAPAY ZEKÂ ASİSTANLARI")
        root.addView(row(btn("◉  VERON", cyan) { startSpeech() }, btn("◉  VERA", gold) { showVeraCommands() }))
        root.addView(actionCard("HIZLI BAŞLANGIÇ", "YB Aurora'yı telefonunun ana ekranı yapmak için varsayılan başlatıcı olarak seçebilirsin.", "Ana ekranı etkinleştir", cyan) { showLauncherHelp() })
        root.addView(label("YB AURORA  •  TASARIM SÜRÜMÜ 1.1", 9f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) })
        bottomNav("home")
    }

    private fun showCommunication() {
        base("İLETİŞİM MERKEZİ", "ARAMA  /  MESAJ  /  WHATSAPP")
        section("HIZLI İŞLEMLER")
        root.addView(actionCard("TELEFON", "Numara tuşlamak ve arama başlatmak için Android telefon uygulamasını açar.", "Telefonu aç", cyan) { openDialer() })
        root.addView(actionCard("SMS MESAJLARI", "Varsayılan mesajlaşma uygulamasında yeni mesaj oluşturur.", "Mesaj yaz", cyan) { openSms() })
        root.addView(actionCard("WHATSAPP", "Resmî WhatsApp uygulamasını açar. Sohbet ve aramalar WhatsApp üzerinden yürütülür.", "WhatsApp'ı aç", gold) { openWhatsApp() })
        root.addView(actionCard("GELEN ARAMA TASARIMI", "Aurora gelen arama ekranının görsel önizlemesi. Gerçek çağrı ekranı için varsayılan telefon rolü gerekir.", "Önizlemeyi gör", gold) { showIncomingPreview() })
        bottomNav("contact")
    }

    private fun showIncomingPreview() {
        base("GELEN ARAMA", "AURORA CALL INTERFACE  /  ÖNİZLEME")
        root.addView(space(35))
        root.addView(label("◉", 76f, cyan).apply { gravity = Gravity.CENTER })
        root.addView(label("BİLİNMEYEN ARAYAN", 19f, 0xFFFFFFFF.toInt()).apply { gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(6)) })
        root.addView(label("Gelen arama ekranı tasarım önizlemesi", 11f, muted).apply { gravity = Gravity.CENTER })
        root.addView(space(45))
        root.addView(row(btn("Reddet", 0xFFFF6B75.toInt()) { say("Önizleme modunda gerçek arama yok.") }, btn("Yanıtla", 0xFF66E6A5.toInt()) { say("Önizleme modunda gerçek arama yok.") }))
        root.addView(space(18))
        root.addView(label("Bu ekran şu anda önizlemedir; gerçek gelen çağrıları yönetmez. Bunun için Android varsayılan telefon uygulaması rolü ve Telecom InCallService entegrasyonu gerekir.", 11f, muted))
        root.addView(btn("Telefon rolü uygunluğunu kontrol et", gold) { requestDialerRole() })
        root.addView(btn("Ana ekrana dön", cyan) { showHome() })
    }

    private fun showSettings() {
        base("ÖZEL AYARLAR", "YB AURORA  /  SİSTEM KİŞİSELLEŞTİRME")
        section("GÖRÜNÜM")
        root.addView(actionCard("JARVIS TEMASI", "Siyah arka plan, elektrik mavisi ve altın vurgular.", "Tema bilgisi", cyan) { say("Aurora koyu tema etkin.") })
        root.addView(actionCard("ANA EKRAN UYGULAMASI", "YB Aurora'yı varsayılan başlatıcı olarak seç.", "Başlatıcı ayarları", gold) { showLauncherHelp() })
        section("İZİNLER VE GİZLİLİK")
        root.addView(actionCard("UYGULAMA İZİNLERİ", "Mikrofon, bildirim ve diğer izinleri Android ayarlarından yönet.", "İzinleri aç", cyan) { openAppSettings() })
        root.addView(actionCard("BİLDİRİM ERİŞİMİ", "Bildirim özetleme özelliği için kullanıcı tarafından ayrıca etkinleştirilir.", "Bildirim ayarları", gold) { openNotificationSettings() })
        section("ASİSTAN")
        root.addView(actionCard("VERON VE VERA", "Ses ve komut özellikleri geliştirme aşamasında. Bu sürümde temel sesli komut tanıma cihazdaki Android hizmetini kullanır.", "Veron'u dene", cyan) { startSpeech() })
        bottomNav("settings")
    }

    private fun showControlCenter() {
        AlertDialog.Builder(this).setTitle("AURORA KONTROL MERKEZİ")
            .setItems(arrayOf("Feneri aç/kapat", "Wi-Fi ayarları", "Bluetooth ayarları", "Uygulama izinleri", "Özel ayarlar")) { _, n ->
                when (n) {
                    0 -> toggleTorch()
                    1 -> openIntent(Intent(Settings.ACTION_WIFI_SETTINGS))
                    2 -> openIntent(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                    3 -> openAppSettings()
                    4 -> showSettings()
                }
            }.setNegativeButton("Kapat", null).show()
    }

    private fun showVeraCommands() {
        AlertDialog.Builder(this).setTitle("VERA • HIZLI KOMUTLAR")
            .setItems(arrayOf("Telefonu aç", "SMS aç", "WhatsApp aç", "Feneri aç/kapat", "Kontrol merkezini aç")) { _, n ->
                when (n) { 0 -> openDialer(); 1 -> openSms(); 2 -> openWhatsApp(); 3 -> toggleTorch(); 4 -> showControlCenter() }
            }.setNegativeButton("Kapat", null).show()
    }

    private fun openDialer() = openIntent(Intent(Intent.ACTION_DIAL))
    private fun openSms() = openIntent(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))
    private fun openWhatsApp() = openPackage("com.whatsapp")
    private fun openPackage(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i) else toast("Uygulama bulunamadı: $pkg")
    }
    private fun openIntent(i: Intent) { try { startActivity(i) } catch (_: Exception) { toast("Bu işlem için uygun uygulama bulunamadı.") } }

    private fun startSpeech() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micRequest); return
        }
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Veron komutunu söyle")
            }
            startActivityForResult(i, speechRequest)
        } catch (_: Exception) { toast("Bu cihazda konuşma tanıma servisi kullanılamıyor.") }
    }

    @Deprecated("Android activity result compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            status.text = "ALGILANAN KOMUT: $words"
            handleCommand(words)
        }
    }

    private fun handleCommand(command: String) {
        val c = command.lowercase(Locale("tr", "TR"))
        when {
            "fener" in c -> { say("Feneri kontrol ediyorum."); toggleTorch() }
            "telefon" in c || "ara" in c -> { say("Telefon uygulamasını açıyorum."); openDialer() }
            "mesaj" in c || "sms" in c -> { say("Mesajları açıyorum."); openSms() }
            "whatsapp" in c -> { say("WhatsApp açılıyor."); openWhatsApp() }
            "ayar" in c -> showSettings()
            "vera" in c -> { say("Vera hazır."); showVeraCommands() }
            "kontrol" in c -> showControlCenter()
            else -> say("Komut algılandı ancak bu sürümde bu işlem tanımlı değil.")
        }
    }

    private fun requestDialerRole() {
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(ROLE_SERVICE) as RoleManager
            if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 990)
            } else if (rm.isRoleHeld(RoleManager.ROLE_DIALER)) toast("YB Aurora telefon rolüne sahip.")
            else toast("Bu cihazda telefon rolü kullanılamıyor.")
        } else toast("Telefon rolü isteği bu Android sürümünde desteklenmiyor.")
    }

    private fun openAppSettings() = openIntent(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    private fun openNotificationSettings() = openIntent(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
    private fun showLauncherHelp() {
        AlertDialog.Builder(this).setTitle("Varsayılan ana ekran")
            .setMessage("Android Ayarları > Uygulamalar > Varsayılan uygulamalar > Ana ekran uygulaması bölümünden YB Aurora'yı seç. Menü adları cihaza göre değişebilir.")
            .setPositiveButton("Tamam", null).show()
    }

    private fun toggleTorch() {
        try {
            val m = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = m.cameraIdList.firstOrNull { m.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { toast("Fener bulunamadı."); return }
            torchOn = !torchOn; m.setTorchMode(id, torchOn)
            status.text = if (torchOn) "FENER AÇIK" else "SİSTEM HAZIR • Komut bekleniyor"
        } catch (_: Exception) { toast("Fener açılamadı.") }
    }

    private fun bottomNav(active: String) {
        root.addView(space(12))
        root.addView(row(
            btn("Ana sayfa", if (active == "home") gold else cyan) { showHome() },
            btn("İletişim", if (active == "contact") gold else cyan) { showCommunication() }
        ))
        root.addView(row(
            btn("Ayarlar", if (active == "settings") gold else cyan) { showSettings() },
            btn("Veron", cyan) { startSpeech() }
        ))
    }

    private fun actionCard(title: String, desc: String, action: String, color: Int, click: () -> Unit): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); background = panelShape(panel, 0xFF263B52.toInt())
            addView(label(title, 13f, color))
            addView(label(desc, 11f, muted).apply { setPadding(0, dp(6), 0, dp(8)) })
            addView(btn(action, color, click))
            val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(5), 0, dp(5)); layoutParams = lp
        }

    private fun section(s: String) { root.addView(label(s, 11f, gold).apply { setPadding(0, dp(18), 0, dp(8)) }) }
    private fun label(s: String, size: Float, color: Int) = TextView(this).apply { text = s; textSize = size; setTextColor(color) }
    private fun btn(s: String, color: Int, click: () -> Unit) = Button(this).apply {
        text = s; textSize = 11f; isAllCaps = false; setTextColor(color)
        background = panelShape(0xFF101C2B.toInt(), color)
        stateListAnimator = null
        setPadding(dp(8), dp(5), dp(8), dp(5))
        setOnClickListener { click() }
    }
    private fun panelShape(fill: Int, stroke: Int) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(15).toFloat()
        setColor(fill)
        setStroke(dp(1), stroke)
    }
    private fun row(a: View, b: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(0, dp(4), dp(5), dp(4)) })
        addView(b, LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(dp(5), dp(4), 0, dp(4)) })
    }
    private fun space(v: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(v)) }
    private fun match() = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(10), 0, dp(5)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun say(s: String) { status.text = s; tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "aurora-utterance") }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        if (torchOn) try { val m = getSystemService(CAMERA_SERVICE) as CameraManager; m.cameraIdList.firstOrNull()?.let { m.setTorchMode(it, false) } } catch (_: Exception) {}
        tts?.shutdown(); super.onDestroy()
    }
}
