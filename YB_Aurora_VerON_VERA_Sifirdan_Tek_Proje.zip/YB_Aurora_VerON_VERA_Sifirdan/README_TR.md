# YB Aurora — Veron & Vera (sıfırdan Android proje paketi)

Bu ZIP, tek bir Android Studio/Gradle projesi ve GitHub Actions derleme iş akışı içerir. Kaynak dosyalarını tek tek kopyalaman gerekmez.

## İçerik
- JARVIS esintili koyu arayüz; siyah/lacivert yüzeyler, elektrik mavisi ve altın vurgular
- Varsayılan ana ekran (launcher) olarak seçilebilen Activity
- Telefon, Chrome, Kamera, Galeri, WhatsApp, Mesajlar ve müzik uygulamalarını açan kısayollar
- Kontrol merkezi menüsü ve fener kontrolü
- Türkçe konuşma tanıma başlatma, temel komut eşleme ve Türkçe metin okuma
- Vera hızlı komut menüsü
- YB imzalı kilit ekranı görsel önizlemesi
- GitHub Actions ile APK derleme ve APK artifact yükleme

## Gerçekçi Android sınırları
- Bu proje bir **ilk çalışan temel sürüm / başlangıç uygulamasıdır**; Veron'un çevrimiçi muhakeme motoru, kalıcı kişisel hafıza, kendi kendini geliştirme veya kapsamlı sistem kontrolü henüz dahil değildir.
- Kilit ekranı yalnızca önizlemedir. Normal bir uygulama Android'in güvenli kilit ekranını kaldıramaz veya onun yerine geçemez.
- Android izinleri olmadan başka uygulamaların özel verilerine erişilemez; sistem izinleri/varsayılan uygulama seçimi kullanıcı tarafından onaylanmalıdır.
- Konuşma tanıma hizmetinin cihazda bulunması ve bazı cihazlarda internet bağlantısı gerekebilir.
- Paket burada statik olarak hazırlanmıştır; bu çalışma ortamında Android SDK/Gradle derlemesi çalıştırılıp APK doğrulanmamıştır. APK oluşturma iş akışı GitHub Actions içinde bunu yapar.

## APK oluşturma (tek seferlik)
1. Bu ZIP'i aç.
2. İçindeki tüm dosyaları GitHub deposunun **kök dizinine** yükle (ZIP dosyasını tek başına depoya koymak yeterli değildir).
3. GitHub deposunda **Actions → YB Aurora Veron Vera Android APK → Run workflow** seç.
4. İş akışı başarılı olunca aynı çalıştırmanın **Artifacts** bölümünden `YB-Aurora-Veron-Vera-debug-apk` dosyasını indir. ZIP artifact içinden `app-debug.apk` çıkar.
5. Android'de APK'yı kur. Ardından Ana ekran uygulaması seçicisinden YB Aurora'yı varsayılan launcher yap.

## Yerel derleme
JDK 17 ve Android SDK gerekir:
`gradle assembleDebug`
