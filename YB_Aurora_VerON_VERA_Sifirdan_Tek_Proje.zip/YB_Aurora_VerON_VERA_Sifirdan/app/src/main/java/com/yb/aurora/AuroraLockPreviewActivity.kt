package com.yb.aurora

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AuroraLockPreviewActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF050912.toInt()
        window.navigationBarColor = 0xFF050912.toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFF050912.toInt())
        }
        box.addView(TextView(this).apply {
            text = "YB"
            textSize = 15f; setTextColor(0xFFFFC66D.toInt())
        })
        box.addView(TextView(this).apply {
            text = SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(Date())
            textSize = 58f; setTextColor(0xFF50D9FF.toInt())
            gravity = Gravity.CENTER
        })
        box.addView(TextView(this).apply {
            text = SimpleDateFormat("EEEE, d MMMM", Locale("tr", "TR")).format(Date())
            textSize = 14f; setTextColor(0xFFE1EAF7.toInt())
            gravity = Gravity.CENTER
        })
        box.addView(TextView(this).apply {
            text = "\\n“Gelecek, onu tasarlamaya cesaret edenlerindir.”\\n\\nVERON • VERA"
            textSize = 15f; setTextColor(0xFFFFC66D.toInt())
            gravity = Gravity.CENTER
        })
        box.addView(TextView(this).apply {
            text = "\\nBu bir kilit ekranı TASLAĞIDIR. Android'in güvenli sistem kilidinin yerine geçmez.\\n\\nGeri dönmek için ekrana dokun."
            textSize = 11f; setTextColor(0xFF8EA0B7.toInt())
            gravity = Gravity.CENTER
        })
        box.setOnClickListener { finish() }
        setContentView(box)
    }
}
