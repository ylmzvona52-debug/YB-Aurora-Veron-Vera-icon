package com.yb.aurora

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private var tts: TextToSpeech? = null
    private var torchOn = false
    private val micRequest = 741
    private val speechRequest = 742
    private val cyan = 0xFF50D9FF.toInt()
    private val gold = 0xFFFFC66D.toInt()
    private val bg = 0xFF070B12.toInt()
    private val panel = 0xFF111A28.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        tts = TextToSpeech(this, this)
        renderHome()
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts?.language = Locale("tr", "TR")
    }

    private fun renderHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "YB  /  AURORA"
            textSize = 13f; letterSpacing = .24f; setTextColor(gold)
        })
        root.addView(TextView(this).apply {
            text = "VERON  •  VERA"
            textSize = 29f; letterSpacing = .08f; setTextColor(cyan)
            setPadding(0, dp(8), 0, dp(2))
        })
        root.addView(TextView(this).apply {
            text = "SİSTEM ARAYÜZÜ  /  ÇEVRİMİÇİ DEĞİLSE TEMEL KOMUTLAR"
            textSize = 10f; setTextColor(0xFF9DAEC4.toInt())
        })
        val orb = TextView(this).apply {
            text = "◉"
            gravity = Gravity.CENTER
            textSize = 72f
            setTextColor(cyan)
            setPadding(0, dp(8), 0, dp(4))
        }
        root.addView(orb, LinearLayout.LayoutParams(-1, dp(110)))
        status = TextView(this).apply {
            text = "SİSTEM HAZIR • Komut bekleniyor"
            textSize = 13f; setTextColor(0xFFE1EAF7.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
        }
        root.addView(status, match())
        section("HIZLI ERİŞİM")
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        grid.addView(row(
            button("Telefon", cyan) { openApp("com.google.android.dialer") },
            button("Chrome", cyan) { openApp("com.android.chrome") }
        ))
        grid.addView(row(
            button("Kamera", cyan) { openIntent(Intent("android.media.action.IMAGE_CAPTURE")) },
            button("Galeri", cyan) { openIntent(Intent(Intent.ACTION_VIEW).setType("image/*")) }
        ))
        grid.addView(row(
            button("WhatsApp", cyan) { openApp("com.whatsapp") },
            button("Mesajlar", cyan) { openIntent(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)) }
        ))
        grid.addView(row(
            button("Müzik", cyan) { openIntent(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC)) },
            button("Kontrol Merkezi", gold) { showControlCenter() }
        ))
        root.addView(grid)
        section("VERON & VERA")
        root.addView(row(
            button("🎙 Veron konuş", cyan) { startSpeech() },
            button("Vera hızlı komut", gold) { showVeraCommands() }
        ))
        root.addView(row(
            button("Kilit ekranı önizleme", gold) {
                startActivity(Intent(this, AuroraLockPreviewActivity::class.java))
            },
            button("Varsayılan ana ekran", cyan) { showLauncherHelp() }
        ))
        root.addView(TextView(this).apply {
            text = "YB AURORA  •  ANDROID  •  SÜRÜM 1.0.0\\nBu uygulama Android'in izin verdiği alanlarda çalışır."
            textSize = 10f; setTextColor(0xFF71839A.toInt())
            setPadding(0, dp(20), 0, dp(8))
        })
    }

    private fun section(title: String) {
        root.addView(TextView(this).apply {
            text = title
            textSize = 11f; letterSpacing = .18f; setTextColor(gold)
            setPadding(0, dp(20), 0, dp(9))
        })
    }

    private fun row(a: View, b: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, dp(58), 1f).apply { setMargins(0, dp(4), dp(5), dp(4)) })
        addView(b, LinearLayout.LayoutParams(0, dp(58), 1f).apply { setMargins(dp(5), dp(4), 0, dp(4)) })
    }

    private fun button(label: String, color: Int, action: () -> Unit): Button =
        Button(this).apply {
            text = label; textSize = 11f; isAllCaps = false
            setTextColor(color)
            setBackgroundColor(panel)
            setOnClickListener { action() }
        }

    private fun match() = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(10), 0, dp(5)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun openApp(packageName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch) else toast("Uygulama bulunamadı: $packageName")
    }
    private fun openIntent(intent: Intent) {
        try { startActivity(intent) } catch (_: Exception) { toast("Bu işlem için uygun uygulama bulunamadı.") }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun showControlCenter() {
        val options = arrayOf("Feneri aç/kapat", "Sesli komut", "Kilit ekranı önizlemesi", "Varsayılan launcher seçimi")
        AlertDialog.Builder(this).setTitle("AURORA KONTROL MERKEZİ").setItems(options) { _, which ->
            when (which) {
                0 -> toggleTorch()
                1 -> startSpeech()
                2 -> startActivity(Intent(this, AuroraLockPreviewActivity::class.java))
                3 -> showLauncherHelp()
            }
        }.setNegativeButton("Kapat", null).show()
    }

    private fun toggleTorch() {
        try {
            val manager = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { toast("Bu cihazda fener bulunamadı."); return }
            torchOn = !torchOn
            manager.setTorchMode(id, torchOn)
            status.text = if (torchOn) "FENER AÇIK • AURORA KONTROL MERKEZİ" else "SİSTEM HAZIR • Komut bekleniyor"
        } catch (e: Exception) { toast("Fener açılamadı: izin veya donanım kısıtı.") }
    }

    private fun startSpeech() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micRequest)
            return
        }
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Veron komutunu söyle")
            startActivityForResult(i, speechRequest)
        } catch (_: Exception) { toast("Bu cihazda konuşma tanıma servisi kullanılamıyor.") }
    }

    @Deprecated("Android activity result compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            status.text = "ALGILANAN KOMUT: $words"
            handleCommand(words)
        }
    }

    private fun handleCommand(command: String) {
        val c = command.lowercase(Locale("tr", "TR"))
        when {
            "fener" in c -> { say("Fener kontrolünü açıyorum."); toggleTorch() }
            "chrome" in c || "tarayıcı" in c -> { say("Tarayıcı açılıyor."); openApp("com.android.chrome") }
            "kamera" in c -> { say("Kamera açılıyor."); openIntent(Intent("android.media.action.IMAGE_CAPTURE")) }
            "kontrol merkezi" in c -> { say("Kontrol merkezi açılıyor."); showControlCenter() }
            "vera" in c -> { say("Vera hazır. Hızlı komut menüsünü açıyorum."); showVeraCommands() }
            else -> say("Komut algılandı. Bu temel sürümde bu işlem için bir eylem tanımlı değil.")
        }
    }

    private fun showVeraCommands() {
        val commands = arrayOf("Feneri aç/kapat", "Chrome'u aç", "Kamerayı aç", "Kontrol merkezini aç")
        AlertDialog.Builder(this).setTitle("VERA • HIZLI KOMUTLAR").setItems(commands) { _, which ->
            when (which) {
                0 -> toggleTorch()
                1 -> openApp("com.android.chrome")
                2 -> openIntent(Intent("android.media.action.IMAGE_CAPTURE"))
                3 -> showControlCenter()
            }
        }.setNegativeButton("Kapat", null).show()
    }

    private fun showLauncherHelp() {
        AlertDialog.Builder(this)
            .setTitle("Varsayılan ana ekran")
            .setMessage("Android Ayarları > Uygulamalar > Varsayılan uygulamalar > Ana ekran uygulaması bölümünden YB Aurora'yı seç. Üreticiye göre menü adları değişebilir.")
            .setPositiveButton("Tamam", null).show()
    }

    private fun say(text: String) {
        status.text = text
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aurora-utterance")
    }

    override fun onDestroy() {
        if (torchOn) try { (getSystemService(CAMERA_SERVICE) as CameraManager).setTorchMode(
            (getSystemService(CAMERA_SERVICE) as CameraManager).cameraIdList.first(), false
        ) } catch (_: Exception) {}
        tts?.shutdown()
        super.onDestroy()
    }
}
