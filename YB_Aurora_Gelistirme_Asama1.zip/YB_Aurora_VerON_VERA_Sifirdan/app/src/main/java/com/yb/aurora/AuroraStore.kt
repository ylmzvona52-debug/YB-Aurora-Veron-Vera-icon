package com.yb.aurora

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Yerel cihaz hafızası: konuşma/not/bildirim kayıtları cihazdan çıkmaz. */
class AuroraStore(context: Context) : SQLiteOpenHelper(context, "aurora_local.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            package_name TEXT NOT NULL,
            title TEXT NOT NULL,
            body TEXT NOT NULL,
            posted_at INTEGER NOT NULL
        )""")
        db.execSQL("""CREATE TABLE memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            assistant TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at INTEGER NOT NULL
        )""")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Sürüm yükseltmelerinde mevcut kullanıcı verisini koruyacak migration eklenecek.
    }

    fun saveNotification(packageName: String, title: String, body: String, postedAt: Long) {
        val values = ContentValues().apply {
            put("package_name", packageName)
            put("title", title)
            put("body", body)
            put("posted_at", postedAt)
        }
        writableDatabase.insert("notifications", null, values)
    }

    fun notificationSummary(limit: Int = 30): List<String> {
        val result = mutableListOf<String>()
        readableDatabase.rawQuery(
            "SELECT package_name, title, body FROM notifications ORDER BY posted_at DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                result += "${c.getString(0)} | ${c.getString(1)}: ${c.getString(2)}"
            }
        }
        return result
    }

    fun saveMemory(assistant: String, role: String, content: String) {
        val values = ContentValues().apply {
            put("assistant", assistant)
            put("role", role)
            put("content", content)
            put("created_at", System.currentTimeMillis())
        }
        writableDatabase.insert("memories", null, values)
    }
}
