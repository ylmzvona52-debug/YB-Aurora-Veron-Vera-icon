package com.yb.aurora

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Vera'nın bildirim alıcısı.
 * Android, kullanıcı Ayarlar'dan bildirim erişimini açmadan bu servisi bağlamaz.
 * Bildirimler cihazda tutulur; hiçbir sunucuya gönderilmez.
 */
class AuroraNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        AuroraStore(this).saveNotification(
            packageName = sbn.packageName,
            title = title,
            body = text,
            postedAt = sbn.postTime
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // Bildirim kaldırılması geçmiş kaydını silmez; kullanıcı rapor isteyebilir.
    }
}
