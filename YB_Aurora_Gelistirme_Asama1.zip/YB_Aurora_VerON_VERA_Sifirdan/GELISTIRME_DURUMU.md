# YB Aurora — geliştirme aşaması 1

Bu paket mevcut `com.yb.aurora` Android projesinin üzerine hazırlanmıştır.

## Bu aşamada eklenen
- Vera için Android `NotificationListenerService` altyapısı.
- Bildirim başlığı, metni, kaynak paket adı ve zamanının yerel SQLite veritabanına kaydı.
- Veron/Vera hafıza kayıtları için yerel SQLite tablosu.
- Bildirim erişimi Android ayarlarından kullanıcı tarafından açılmalıdır.

## Henüz tamamlanmayanlar
- llama.cpp JNI/NDK entegrasyonu ve indirilebilir GGUF model paketi.
- Gerçek yerel LLM yanıt üretimi.
- Sürekli Hey Veron algılama ve mikrofon ön plan servisi.
- Tüm bildirimlerin güvenli, kullanıcı kontrollü özet ekranı.
- Oyun ekranı analizi/otomatik kontrol.
- Cihaz üzerinde derleme ve çalışma testi.

Bu aşama tek başına tamamlanmış bir yapay zekâ uygulaması değildir. Gerçek AI motoru eklenmeden Veron'un düşünüyor olduğu iddia edilmez.
